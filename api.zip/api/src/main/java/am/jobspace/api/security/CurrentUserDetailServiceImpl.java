package am.jobspace.api.security;



//@Service
public class CurrentUserDetailServiceImpl{}
//    implements UserDetailsService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Override
//    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
//        Optional<User> user = userRepository.findByEmail(s);
//        if (!user.isPresent()) {
//            throw new UsernameNotFoundException("Username not found");
//        }
//        return new CurrentUser(user.get());
//    }
//}
