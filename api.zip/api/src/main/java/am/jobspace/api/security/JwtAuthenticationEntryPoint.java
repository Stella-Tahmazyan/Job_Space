package am.jobspace.api.security;


//@Component
public class JwtAuthenticationEntryPoint {}

//    implements AuthenticationEntryPoint, Serializable {
//
//    @Override
//    public void commence(HttpServletRequest request,
//                         HttpServletResponse response,
//                         AuthenticationException authException) throws IOException {
//        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
//    }
//}